#import "HPSEditTextCell.h"

@implementation HPSEditTextCell
- (void)setSeparatorStyle:(UITableViewCellSeparatorStyle)style {
  [super setSeparatorStyle:UITableViewCellSeparatorStyleNone];
}
@end
